// const color = require("cli-color")
// console.log(color.red("hello i am avinash"))



import chalk from 'chalk';
chalk = require('chalk');

const log = console.log;

// Combine styled and normal strings
log(chalk.blue('Hello') + ' World' + chalk.red('!'));
