//http module
// const http = require('http')
// const fs = require("fs")
// const path = require("path")

// const server = http.createServer((req,res)=>{
//     res.writeHead(200,{
//         "Content-Type":"text/plain"
//     })
//    if(req.url==="/"){
//     fs.readFile(path.join(__dirname,'public','index.html'),'utf-8',(err,data)=>{
//         if(err){
//             throw err
//         } 
//         res.end(data)
//      })
  
//    }
//    else if(req.url==='/about'){
//     fs.readFile(path.join(__dirname,'public','about.html'),'utf-8',(err,data)=>{
//         if(err){
//             throw err
//         } 
//         res.end(data)
//      })
  
//    }
// })

// const PORT = process.env.PORT || 3000
// server.listen(PORT,'127.0.0.1',()=>{
//     console.log(`listening to the port ${PORT}`)
// })

