// //NPM module
const color = require("cli-color")
console.log(color.red("hello i am avinash"))

// //local module
// // let auth = require('./auth')

// // auth.register('avinash')
// // auth.login("aviansh",'aci')

// // //core modules


// //  //path module
// const path = require("path")

// // //dirname
// //   console.log("folder name : ",path.dirname(__filename))

// // //file name
// //  console.log("file  name : ",path.basename(__filename))

// //  //extension
// //  console.log("extension name : ",path.extname(__filename))

// //  //parse
// //  console.log("parse : ",path.parse(__filename))

// //  //join
// //  console.log("join : ",path.join(__dirname,"order","app.js"))

// //file system module

// // const fs =  require('fs')

// // //make a dir
// // fs.mkdir(path.join(__dirname,'test'),(err)=>{
// //     if(err){
// //         // console.log("something went wrong")
// //         console.log(err)
// //         return
// //     }
// //     console.log("folder created")
// // })

// // //create a file

// // fs.writeFile(path.join(__dirname,'test','note.txt'),"namaste node.js \n",(err)=>{
// //    if(err){
// //        throw err
// //    }
// //    fs.appendFile(path.join(__dirname,'test','note.txt'),' i am avinash',()=>{
// //        if(err){
// //            throw err
// //        }
// //    })
   

// // })
// // console.log("file is created..")


// // //read file

// // fs.readFile(path.join(__dirname,'test','note.txt'),'utf-8',(err,data)=>{
// //  if(err){
// //      throw err
// //  }
// //  console.log(data)
// // //  const content = Buffer.from(data)
 
// // //  console.log(content.toString())
// // })

// //os module
// const os =  require('os')
// // console.log("os type : ",os.type())
// // console.log("os paltform : ",os.platform())
// // console.log("cpu architecture : ",os.arch())
// console.log("cpu details : ",os.cpus())
// console.log("free memory : ",os.freemem())
// console.log("total memory : ",os.totalmem())
// console.log("up time : ",os.uptime())



// //events module
// const Emitter = require('events')

// // const myEmitter = new Emitter()

// // myEmitter.on("somename",(data)=>{
// //  console.log(data)
// // })
// // myEmitter.emit('somename',{
// //     name:'avinash'
// // })

// class Auth extends Emitter{
//     register(username){
//         console.log("registered successfully....")
//         this.emit("registered",username)
//     }
// }

// const auth = new Auth()
// //listen
// auth.on('register',(data)=>{
//     console.log(`sending email to ${data}`)
// })
// auth.register("avinash")



