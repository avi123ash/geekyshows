// const express = require('express')
import express  from "express"  //es6 syntax
const app = express()
const port = process.env.PORT || '3000'

app.get('/',(req,res)=>{
    res.send("<h1>hello from the server</h1>")
})







app.listen(port,()=>{
    console.log(`listening on the port at http://localhost:${port}`)
})