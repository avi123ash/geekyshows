 //this is old way of doing 
// const express = require('express')
//by es6 method
import express from 'express'

const app = express()

 
app.get('/', function (req, res) {
  res.send('<h1>hello world!</h1>')
})
 
app.listen(3000,()=>{
    console.log("listening on port http://localhost:3000")
})
