// routing 
// const express = require('express')

import express from "express";  //es6 way
const app = express()

const port = process.env.PORT || 3000

// routes
app.get('/',(req,res)=>{
    res.send("<h1>this is get method</h1>")
})
//  app.all('*',(req,res)=>{
//      res.send("<h1>page not found</h1>")
// })
//  app.all('/api/*',(req,res)=>{
//      res.send("<h1>api page</h1>")
// })


// string path

app.get('/about',(req,res)=>{
    res.send("<h1>about page</h1>")
})
app.get('/contact',(req,res)=>{
    res.send("<h1>contact page</h1>")
})

// string pattern path

app.get('/ab?cd',(req,res)=>{
    res.send("<h1>this route path will match acd and abcd</h1>")
})

//regular expression path

// app.get(/a/,(req,res)=>{
//     res.send("<h1>this is a </h1>")
// })

//one call back function
// app.get('/cbexample1',(req,res)=>{
//     res.send("<h1>one callback example</h1>")
// })

// //more than one call back function
// app.get('/cbexample2',(req,res,next)=>{
//     console.log("first call back")
//     next()
// },(req,res)=>{
//     console.log("second call back")
//     res.send('more than one call back function')
// }

// )




//array of call back

// const cb1 =(req,res,next)=>{
//     console.log('first callback')
//     next()
// }

// const cb2 =(req,res,next)=>{
//     console.log('second callback')
//     next()
// }

// const cb3 =(req,res,next)=>{
//     console.log('third callback')
    
//     res.send('an array of call back function')
// }

// app.get("/cbexample3",[cb1,cb2,cb3])



// combination of both
// const cb1 =(req,res,next)=>{
//     console.log('first callback')
//       next()
//   }
// const cb2 =(req,res,next)=>{
//     console.log('second callback')
//       next()
//   }
//   app.get("/cbexample4",[cb1,cb2],(req,res,next)=>{
//       console.log("third callback")
//       next()
//   },(req,res)=>{
//       console.log("fourth callback")
//       res.send('combination of both')
//   })


// chained route callback














app.listen(port,()=>{
    console.log(`listening on the port http://localhost:${port}`)
})