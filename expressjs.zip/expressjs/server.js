const express = require("express")
const path = require('path')
const app = express()
const mainRouter = require('./routes/index.js')
//environment variable checking
const PORT = process.env.PORT || 3000
app.set('view engine','ejs')
// console.log(app.get('view engine'))
// console.log(app.get('views'))

app.use(express.static('public'))
app.use(mainRouter)












//this is for home page..
// app.get('/',(req,res)=>{
//     // res.send("<h1>hello from express server</h1>")
//     res.render('index',{
//         'title':'my home page'
//     })
// })
//this is for about page..
// app.get('/about',(req,res)=>{
//     res.render('about',{
//         'title':'my about page'
//     })
// })
// this is for download by using static way...
// app.get('/download',(req,res)=>{
//     res.download(path.resolve(__dirname)+'/about.html')
// })



//to create the server we used listen() function
app.listen(PORT,()=>{
    // this call back function is called when the server starts
    console.log(`listening on  port ${PORT}`)
})

