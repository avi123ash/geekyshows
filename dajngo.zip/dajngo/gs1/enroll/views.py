from email import message
from django import forms
from django.shortcuts import render
from .forms import SignUp
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
# Create your views here.
def sign_in(req):
    fm = AuthenticationForm()
    return render(req,'enroll/home.html',{'form':fm})

def sign_up(request):
    if request.method == 'POST':
        fm = SignUp(request.POST)
        if fm.is_valid():
            messages.success(request,'accout created successfully')
            fm.save()

    else:
     fm = SignUp()
    return render(request,'enroll/index.html',{'form':fm})
